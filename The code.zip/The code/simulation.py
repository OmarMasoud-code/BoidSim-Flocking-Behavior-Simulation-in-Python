import csv
import numpy as np
from Boid import Boid

def save_positions_velocities(filename, flock):
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['Step', 'Boid', 'Position_X', 'Position_Y', 'Velocity_X', 'Velocity_Y'])
        for step, boid in enumerate(flock):
            writer.writerow([step, flock.index(boid), boid.position[0], boid.position[1], boid.velocity[0], boid.velocity[1]])

def simulate_boids(num_boids, num_steps):
    flock = [
        Boid(
            position=np.random.uniform(-50, 50, size=2),
            velocity=np.random.uniform(-1, 1, size=2)
        ) for _ in range(num_boids)
    ]
    for step in range(num_steps):
        for boid in flock:
            boid.decide(flock)
            boid.move()
    return flock

def run_simulation(flock, num_steps, filename, separation_weight, cohesion_weight, alignment_weight):
    for step in range(num_steps):
        for boid in flock:
            boid.decide(flock, separation_weight, cohesion_weight, alignment_weight)
            boid.move()
    save_positions_velocities(filename, flock)
