import numpy as np
from Boid import Boid

def obstacle_avoidance(self, obstacles, avoidance_distance=20):
    avoidance_vector = np.zeros(2)
    for obstacle in obstacles:
        distance = np.linalg.norm(self.position - obstacle)
        if 0 < distance < avoidance_distance:
            avoidance_vector += (self.position - obstacle) / distance
    return avoidance_vector

def decide_with_obstacle_avoidance(self, flock, obstacles, separation_weight=1.0, cohesion_weight=1.0,
                                   alignment_weight=1.0, avoidance_weight=1.0):
    separation_vector = self.separation(flock)
    cohesion_vector = self.cohesion(flock)
    alignment_vector = self.alignment(flock)
    avoidance_vector = self.obstacle_avoidance(obstacles)

    combined_vector = (
            separation_weight * separation_vector +
            cohesion_weight * cohesion_vector +
            alignment_weight * alignment_vector +
            avoidance_weight * avoidance_vector
    )

    speed_factor = self.speed
    self.velocity += speed_factor * combined_vector
    norm = np.linalg.norm(self.velocity)
    if norm != 0:
        self.velocity /= norm

def move_with_variable_speed(self):
    self.position += self.speed * self.velocity


def simulate_boids_with_modifications(num_boids, num_steps, obstacles=None):
    flock = [
        Boid(
            position=np.random.uniform(-50, 50, size=2),
            velocity=np.random.uniform(-1, 1, size=2)
        ) for _ in range(num_boids)
    ]

    for step in range(num_steps):
        for boid in flock:
            if obstacles:
                boid.decide_with_obstacle_avoidance(flock, obstacles)
            else:
                 boid.decide(flock)
            boid.move_with_variable_speed()

    return flock

# Attach the modification functions to the Boid class
Boid.obstacle_avoidance = obstacle_avoidance
Boid.decide_with_obstacle_avoidance = decide_with_obstacle_avoidance
Boid.move_with_variable_speed = move_with_variable_speed
