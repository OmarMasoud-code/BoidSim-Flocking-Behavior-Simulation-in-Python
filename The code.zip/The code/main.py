import numpy as np

from Boid import Boid
from simulation import simulate_boids, run_simulation, save_positions_velocities
from modifications import obstacle_avoidance, decide_with_obstacle_avoidance, move_with_variable_speed, simulate_boids_with_modifications

if __name__ == "__main__":
    # Simulate 10 & 100 boids for 200 steps
    flock_10_boids = simulate_boids(num_boids=10, num_steps=200)
    save_positions_velocities('10_boids.csv', flock_10_boids)
    print("Observation for 10 Boids: With a smaller number of boids, the flock tends to exhibit more random and less organized behavior, check the CSV file.")

    flock_100_boids = simulate_boids(num_boids=100, num_steps=200)
    save_positions_velocities('100_boids.csv', flock_100_boids)
    print("Observation for 100 Boids: Larger groups generally exhibit more cohesive behavior and tend to form clearer patterns, check the CSV file.")

    # Task 3 Simulations
    # Separation & Cohesion
    flock_separation_cohesion = [Boid(
        position=np.random.uniform(-50, 50, size=2),
        velocity=np.random.uniform(-1, 1, size=2)
    ) for _ in range(100)]
    run_simulation(flock_separation_cohesion, num_steps=200, filename='separation_cohesion.csv',
                   separation_weight=1.0, cohesion_weight=1.0, alignment_weight=0.0)
    print("Observation for Separation & Cohesion: Cohesion works against separation, resulting in a balance between staying together and avoiding collisions, check the CSV file.")

    # Separation & Alignment
    flock_separation_alignment = [Boid(
        position=np.random.uniform(-50, 50, size=2),
        velocity=np.random.uniform(-1, 1, size=2)
    ) for _ in range(100)]
    run_simulation(flock_separation_alignment, num_steps=200, filename='separation_alignment.csv',
                   separation_weight=1.0, cohesion_weight=0.0, alignment_weight=1.0)
    print("Observation for Separation & Alignment: Boids focus on avoiding collisions while aligning with the average velocity of nearby neighbors, check the CSV file.")

    # Cohesion & Alignment
    flock_cohesion_alignment = [Boid(
        position=np.random.uniform(-50, 50, size=2),
        velocity=np.random.uniform(-1, 1, size=2)
    ) for _ in range(100)]
    run_simulation(flock_cohesion_alignment, num_steps=200, filename='cohesion_alignment.csv',
                   separation_weight=0.0, cohesion_weight=1.0, alignment_weight=1.0)
    print("Observation for Cohesion & Alignment: Cohesion encourages boids to stay close together, while alignment promotes consistent direction, check the CSV file.")

    # Obstacle Avoidance
    obstacles = [np.array([10, 10]), np.array([-20, 30])]
    flock_with_obstacle_avoidance = simulate_boids_with_modifications(num_boids=50, num_steps=200, obstacles=obstacles)
    save_positions_velocities('obstacle_avoidance.csv', flock_with_obstacle_avoidance)

    # Variable Speed
    flock_with_variable_speed = simulate_boids_with_modifications(num_boids=50, num_steps=200)
    save_positions_velocities('variable_speed.csv', flock_with_variable_speed)
