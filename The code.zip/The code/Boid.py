import numpy as np

class Boid:
    def __init__(self, position, velocity):
        self.position = np.array(position, dtype=float)
        self.velocity = np.array(velocity, dtype=float)
        self.inner_radius = 10
        self.outer_radius = 50
        self.speed = 0.1

    def separation(self, flock):
        separation_vector = np.zeros(2)
        for other_boid in flock:
            if self != other_boid:
                distance = np.linalg.norm(self.position - other_boid.position)
                if 0 < distance < self.inner_radius:
                    separation_vector += (self.position - other_boid.position) / distance
        return separation_vector

    def cohesion(self, flock):
        center_of_mass = np.zeros(2)
        for other_boid in flock:
            if self != other_boid:
                center_of_mass += other_boid.position
        center_of_mass /= len(flock) - 1
        cohesion_vector = (center_of_mass - self.position) / np.linalg.norm(center_of_mass - self.position)
        return cohesion_vector

    def alignment(self, flock):
        avg_velocity = np.zeros(2)
        for other_boid in flock:
            if self != other_boid:
                avg_velocity += other_boid.velocity
        avg_velocity /= len(flock) - 1
        alignment_vector = (avg_velocity - self.velocity) / np.linalg.norm(avg_velocity - self.velocity)
        return alignment_vector

    def decide(self, flock, separation_weight=1.0, cohesion_weight=1.0, alignment_weight=1.0):
        separation_vector = self.separation(flock)
        cohesion_vector = self.cohesion(flock)
        alignment_vector = self.alignment(flock)

        # decision-making is adjusted to the requirements of Task 3
        combined_vector = (
                separation_weight * separation_vector +
                cohesion_weight * cohesion_vector +
                alignment_weight * alignment_vector
        )
        speed_factor = 0.1
        self.velocity += speed_factor * combined_vector

        norm = np.linalg.norm(self.velocity)
        if norm != 0:
            self.velocity /= norm

    def move(self):
        self.position += self.velocity

    # New methods for Task 4
    def obstacle_avoidance(self, obstacles, avoidance_distance=20):
        avoidance_vector = np.zeros(2)
        for obstacle in obstacles:
            distance = np.linalg.norm(self.position - obstacle)
            if 0 < distance < avoidance_distance:
                avoidance_vector += (self.position - obstacle) / distance
        return avoidance_vector

    def decide_with_obstacle_avoidance(self, flock, obstacles, separation_weight=1.0, cohesion_weight=1.0,
                                       alignment_weight=1.0, avoidance_weight=1.0):
        separation_vector = self.separation(flock)
        cohesion_vector = self.cohesion(flock)
        alignment_vector = self.alignment(flock)
        avoidance_vector = self.obstacle_avoidance(obstacles)

        combined_vector = (
                separation_weight * separation_vector +
                cohesion_weight * cohesion_vector +
                alignment_weight * alignment_vector +
                avoidance_weight * avoidance_vector
        )

        speed_factor = self.speed
        self.velocity += speed_factor * combined_vector
        norm = np.linalg.norm(self.velocity)
        if norm != 0:
            self.velocity /= norm

    def move_with_variable_speed(self):
        self.position += self.speed * self.velocity
